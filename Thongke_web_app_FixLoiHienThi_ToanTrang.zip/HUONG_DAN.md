# Đưa lên GitHub và chạy lên https://thongkesxmb.web.app

1. GitHub: mở kho `thong-ke-xsmb` → Add file → Upload files → kéo TOÀN BỘ file trong thư mục này
   (nhớ cả thư mục `.github`) → Commit. Nếu không thấy thư mục `.github`, tạo file
   `.github/workflows/daily_19h.yml` rồi dán nội dung file cùng tên.
2. Settings → Secrets and variables → Actions → Secrets: `FIREBASE_SERVICE_ACCOUNT` = toàn bộ file JSON service account
   (Firebase Console → Project settings → Service accounts → Generate new private key). Dự án phải là `thongkesxmb`.
3. Settings → Actions → General → Workflow permissions → "Read and write permissions".
4. Tab Actions → "Tu Dong Cap Nhat XSMB 19h00 & Deploy Firebase" → Run workflow. Mở log bước "Lay KQXS":
   phải có dòng "Nguồn ...: đọc được N ngày". Nếu báo lỗi nguồn, đặt biến (tab Variables)
   `XSMB_RSS_URLS` = link RSS XSMB khác (nhiều link cách nhau bằng dấu phẩy).
5. Mở https://thongkesxmb.web.app (Ctrl+F5). Từ giờ hệ thống tự chạy 19:00, 19:15 và 19:45 giờ VN mỗi ngày.

Cột giải phụ (C, D, E, AR, AS, G1CN) được bù TỰ ĐỘNG cho toàn bộ lịch sử vào `daily_aux`: mỗi lần chạy tối đa 300 ngày (đổi bằng biến `XSMB_AUX_BUDGET`), nên khoảng 2 lần chạy đầu là đủ hết. Ngày Tết để trống.

Các ô bị làm sạch tự động (ô giữ chỗ 00000, số trùng hệt do dính nhầm) được ghi trong `data.json` → `quality_log`
và trong log của workflow, để bạn đối chiếu và sửa lại bằng tay nếu cần.
